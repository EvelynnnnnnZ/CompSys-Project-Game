    /************************************************************************/
/* File Name : lc4_loader.c		 										*/
/* Purpose   : This file implements the loader (ld) from PennSim		*/
/*             It will be called by main()								*/
/*             															*/
/* Author(s) : tjf and you												*/
/************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include "lc4_memory.h"
#include "lc4_hash.h"

void swapEndianness(unsigned short int *read_num){
  unsigned short int upper8;
  unsigned short int lower8;
  unsigned short int swap_it;

  lower8 = (*read_num & 0x00FF) << 8;
  upper8 = (*read_num & 0xFF00) >> 8; 
  swap_it = lower8 | upper8;
  *read_num = swap_it;
}

/* declarations of functions that must defined in lc4_loader.c */
/**
 * opens up name of the file passed in, returns a pointer
 * to the open file
 *
 * returns the FILE pointer upon success, else NULL.
 */
FILE* open_file(char* file_name)
{
	FILE *opened_file;
	opened_file = fopen(file_name, "rb");
	if (opened_file != NULL){
		return opened_file;					//if file exist, return opened file
	}
  printf ("error in open");
	return NULL ;							//otherwise a NULL should be returned
}

/**
 * parses the given input file into hashtable
 *
 * returns 0 upon successs, non-zero if an error occurs.
 */
int parse_file (FILE* my_obj_file, lc4_memory_segmented* memory)	//******The format of the .OBJ input file has been in lecture, but its layout has been reprinted above (see section: INPUT_FILE_FORMAT).
{
  int i = 0;
  int read_num = 0;
  unsigned short int header_helper = 0;
  unsigned short int address = 0;
  unsigned short int n = 0;
  unsigned short int temp = 0; 
  row_of_memory *for_symbol = NULL;
  char *temp_char = NULL;
  //char temp_char_helper = NULL;

  while(1) {

    if (feof(my_obj_file)) {
      break;
    }
    read_num = fread(&header_helper, sizeof(unsigned short int), 1, my_obj_file); //initiate read_num
    swapEndianness(&header_helper);
    if (read_num<0){ 
      printf("Error2: error with ReadObjectFile read_num NULL");
      return 1;
    }
    else {
      if (header_helper == 0xCADE){           // if it's code

        fread (&address, sizeof(address), 1, my_obj_file);
        swapEndianness(&address);

        fread(&n, sizeof(n), 1, my_obj_file); //initiate read_num
        swapEndianness(&n); 
        
        for (i = 0; i < n; i++){
          fread (&temp, sizeof(unsigned short int), 1, my_obj_file);
          swapEndianness(&temp);
          add_entry_to_tbl (memory, address, temp);
          address++;
        }


      }
      else if (header_helper == 0xDADA){           // if it's data

        
        fread (&address, sizeof(unsigned short int), 1, my_obj_file);
        swapEndianness(&address);

        fread(&n, sizeof(n), 1, my_obj_file); //initiate read_num
        swapEndianness(&n); 

        for (i = 0; i < n; i++){
          fread (&temp, sizeof(unsigned short int), 1, my_obj_file);
          swapEndianness(&temp);
          add_entry_to_tbl (memory, address, temp);
          address++;
        }
      }
      else if (header_helper == 0xC3B7){           // if it's symbol
        fread (&address, sizeof(unsigned short int), 1, my_obj_file);
        swapEndianness(&address);
        fread(&n, sizeof(n), 1, my_obj_file); //initiate read_num
        swapEndianness(&n); 


        temp_char = malloc((n+1) * sizeof(char));

        if (temp_char == NULL){
          fprintf(stdout, "temp_char malloc fails");
          fflush(stdout);
          free(temp_char);
          return 1;
        }

        fread(temp_char, sizeof(char), n, my_obj_file);
        temp_char[n] = '\0';
        for_symbol = search_tbl_by_address(memory, address);

        if (for_symbol == NULL){
          fprintf(stdout, "for_symbol malloc fails");
          fflush(stdout);
          free(temp_char);
          return 1;
        }
        //temp_char_helper = *temp_char;
        for_symbol->label = temp_char;

      }
  }
  }

  fclose(my_obj_file);
  //free(temp_char);
	return 0 ;
}
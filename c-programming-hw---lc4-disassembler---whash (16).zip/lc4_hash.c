/************************************************************************/
/* File Name : lc4_hash.c		 										*/
/* Purpose   : This file contains the definitions for the hash table  	*/
/*																		*/
/* Author(s) : tjf 														*/
/************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include "lc4_hash.h"



/*
 * creates a new hash table with num_of_buckets requested
 */
lc4_memory_segmented* create_hash_table (int num_of_buckets, 
             					         int (*hash_function)(void* table, void *key) ) 
{
	lc4_memory_segmented* my_table = malloc (sizeof(lc4_memory_segmented));
	my_table->hash_function = hash_function;

	if (my_table == NULL){
		printf("malloc fials for my_table");
		return NULL;				//malloc fails
	}

	my_table->buckets = malloc(sizeof(row_of_memory*)*num_of_buckets);

	if (my_table->buckets == NULL){
		printf("malloc fials for buckets");
		return NULL;				//malloc fails
	}

	my_table->num_of_buckets = num_of_buckets;

	return (my_table);
	// allocate a single hash table struct

	// allocate memory for the buckets (head pointers)

	// assign function pointer to call back hashing function

	// // return 0 for success, -1 for failure
	// return 0 ; ****************
}


/*
 * adds a new entry to the table
 */
int add_entry_to_tbl (lc4_memory_segmented* table, 
					  unsigned short int address,
			    	  unsigned short int contents) 
{
	int bucket_num = 0;
	bucket_num = table->hash_function(table, &address);
	//bucket_num = hash_function_helper(address);
	add_to_list(&table->buckets[bucket_num], address, contents);
	// apply hashing function to determine proper bucket #
	// add to bucket's linked list using linked list add_to_list() helper function
	return 0 ;
}

/*
 * search for an address in the hash table
 */
row_of_memory* search_tbl_by_address 	(lc4_memory_segmented* table,
			                   			 unsigned short int address ) 
{
	int bucket_num = 0;
	row_of_memory* search_result;
	bucket_num = table->hash_function(table, &address);
	//bucket_num = hash_function_helper(address);
	search_result = search_address(table->buckets[bucket_num], address);
	if (search_result != NULL){
		return search_result;
	}
	// apply hashing function to determine bucket # item must be located in
	// invoked linked_lists helper function, search_by_address() to return return proper node
	return NULL;
}

/*
 * prints the linked list in a particular bucket
 */

void print_bucket (lc4_memory_segmented* table, 
				   int bucket_number,
				   FILE* output_file ) 
{
	print_list(table->buckets[bucket_number], output_file);
	// call the linked list helper function to print linked list
	return ;
}

/*
 * print the entire table (all buckets)
 */
void print_table (lc4_memory_segmented* table, 
				  FILE* output_file ) 
{
	int i = 0;
	int check = 0;
    fprintf(output_file, "<label>   <address>   <contents>   <assembly>\n");


	for (i = 0; i<4; i++){
		if (table->buckets[i] == NULL){
			check = 1;
		}
		else
		{
			check = 2;
		}
		fprintf(stdout, "in print_table, printing if table->buckets[i] is NULL: %d\n", check);
				fprintf(stdout, "in print_table, printing i: %d\n", i);

		fflush(stdout);
		if (table->buckets[i]!=NULL){
			print_list(table->buckets[i], output_file);
		}
	}
	// call the linked list helper function to print linked list to output file for each bucket
					fprintf(stdout, "ready reaturn\n");

		fflush(stdout);
	return ;
}

/*
 * delete the entire table and underlying linked lists
 */

void delete_table (lc4_memory_segmented* table ) 
{
	int i = 0;
	int check = 0;

	// for (i = 0; i<4; i++){
	// 	if (table->buckets[i]!=NULL){
	// 		delete_list(table->buckets+i);
	// 	}
	// }
	fprintf(stdout, "here in delete_table\n");
	fflush(stdout);
	for (i = 0; i<4; i++){//*******num_of_buckets or just 4?
		 if (table->buckets[i]!=NULL){

			delete_list(&table->buckets[i]);
			
		}
	fprintf(stdout, "i value now: %d\n", i);

		if (table->buckets[0] != NULL){
			check = 2;
		}
		else {
			check = 3;
		}
		fprintf(stdout, "i value after if: %d\n", i);

	fprintf(stdout, "inside for loop, print 3 if table buckets [i] are all NULL: %d\n", check);
	fflush(stdout);

	}
		if (table->buckets[0] != NULL){
			check = 2;
		}
		else {
			check = 3;
		}
	//free(table->buckets);
	fprintf(stdout, "before we free table, print 3 if table buckets [i] are all NULL: %d\n", check);
	fflush(stdout);
	//free(table);
		if (table->buckets[0] != NULL){
			check = 2;
		}
		else {
			check = 3;
		}
	fprintf(stdout, "abouyt to reaturn from delete_table, print 3 if table buckets [i] are all NULL: %d\n", check);
	fflush(stdout);
	

	// fprintf(stdout, "abouyt to reaturn from delete_table, print 3 if table buckets [i] are all NULL: %d\n", check);
	// fflush(stdout);
	// call linked list delete_list() on each bucket in hash table
	// then delete the table itself
	return ;
}
